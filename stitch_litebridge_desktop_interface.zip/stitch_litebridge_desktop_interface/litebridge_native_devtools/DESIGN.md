---
name: LiteBridge Native DevTools
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f22'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#e29100'
  on-tertiary-container: '#523200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-md:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  code-lg:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.375rem
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1.125rem
    letterSpacing: -0.01em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '400'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 0.625rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-xxs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
  space-2xl: 2rem
  titlebar-height: 2.375rem
  sidebar-collapsed-width: 3.5rem
  sidebar-expanded-width: 16rem
  gutter-dense: 0.5rem
  gutter-panel: 1rem
---

## Brand & Style
This design system defines a high-precision, low-latency desktop interface engineered specifically for Tauri v2 native environments. Blending the utilitarian discipline of modern code workspaces (Linear, VS Code) with the effortless tactile polish of next-generation system utilities (Raycast), the aesthetic communicates operational authority, cryptographic rigor, and instantaneous responsiveness.

Key stylistic pillars:
- **Zero-Latency Instrument:** Interfaces must feel lightweight, keyboard-accessible, and devoid of cosmetic friction. Motion is rapid (80–140ms), purposeful, and directly tied to application state transitions.
- **Deep Slate/Zinc Architecture:** Layers of deep obsidian and zinc substrates (#09090b through #18181b) provide an optical sanctuary for developers running persistent background monitors, local LLM bridges, and agent dispatchers.
- **Engineered Micro-Accents:** Vivid terminal emerald, cybernetic cyan, telemetry amber, and compiler crimson serve strictly functional roles—rendering system health, token saturation, process connectivity, and bridge failures legible at a glance.
- **Sub-pixel Rigor:** Crisp 1px hairline borders (`#27272a`) define explicit boundaries across dynamic panels, split panes, and floating titlebars without relying on soft or unfocused drop shadows.

## Colors
The color architecture relies on a dark-first, zinc-slate progression engineered for OLED displays and standard developer monitors alike. Color is never decorative; it acts as a real-time runtime status register.

### Surface System
- **Canvas Base (`#09090b`):** Ground level window chassis and framing layer beneath Tauri's native glass/vibrancy.
- **Subsurface Panel (`#121215`):** Structural sidebar panels, secondary trays, and inactive split panes.
- **Surface Elevated (`#18181b`):** Configuration cards, parameter blocks, and elevated code editor canvases.
- **Surface Hover/Active (`#222226`):** Focused selection states, hover tiles, and dropdown options.

### Borders & Delimiters
- **Hairline Structural (`#27272a`):** Standard non-interactive dividers, card perimeters, and titlebar seams.
- **Border Interactive (`#3f3f46`):** Hover-state boundaries and unfocused input field borders.
- **Focus Ring Glow (`rgba(16, 185, 129, 0.4)`): High-visibility keyboard accessibility ring with zero spread.

### Semantic Telemetry
- **Emerald Primary (`#10b981` / Active `#059669`):** Gateway operational, live bridges, successful agent probes, primary execution triggers.
- **Cyber Cyan Secondary (`#06b6d4`):** Secondary metrics, active runtime models, context stream indices, copy-to-clipboard feedback.
- **Warning Amber (`#f59e0b`):** Config-only stubs, missing local checkpoints, token budget threshold warnings (>80%).
- **Compiler Crimson (`#ef4444`):** Process termination, socket timeouts, parsing exceptions, gateway disconnections.
- **Neutral Missing Slate (`#52525b`):** Missing binaries, offline agents, uninitialized ports.

## Typography
The typographic hierarchy implements a high-density, twin-engine paradigm: **Inter** handles spatial navigation, modal titles, descriptions, and UI controls; **JetBrains Mono** governs programmatic outputs, file paths, model hashes, port addresses, JSON key-values, and terminal previews.

- **Numbers and Metrology:** All tabular counts, ping latencies, and token counters must apply `font-feature-settings: "tnum" 1, "zero" 1` to prevent visual jitter during streaming outputs.
- **Optical Kerning:** Display titles employ tight tracking (`-0.02em`) to echo native macOS/Windows window titles.
- **Telemetry Labels:** Section tags, status indicators, and column headings use `label-caps` in JetBrains Mono with uppercase transformation to create instant visual anchors.

## Layout & Spacing
This system is architected for desktop multi-window ergonomics, accommodating both compact monitor arrangements and ultra-wide side-by-side workstation displays.

### Structure & Master Frame
- **Tauri Native Title Bar (`titlebar-height: 2.375rem` / `38px`):** Top anchored, carrying window management controls (traffic lights or standard min/max/close), drag region metadata (`data-tauri-drag-region`), gateway connection health pill, and persistent global search shortcut (`Cmd+K` / `Ctrl+K`).
- **Two-Column Workstation:**
  - **Left Rail Sidebar:** Fixed width (`16rem` / `256px`), collapsible to an icon-only strip (`3.5rem` / `56px`). Houses persistent agent profiles, core bridge listeners, and hardware health rings.
  - **Primary Viewport:** Fluid flex region composed of a header configuration strip, split-view configuration canvas, and bottom pinned terminal status drawer.
- **Density Grid:** Uses a strict base-4 rhythm (`4px`, `8px`, `12px`, `16px`, `24px`). Panel-internal components prioritize dense alignment (`space-sm` and `space-md`) to ensure critical telemetry remains above the fold without requiring vertical scrolling.

## Elevation & Depth
Depth in this desktop system is established through **tonal stratification and razor-sharp perimeter illumination** rather than heavy diffuse drop shadows, ensuring the app feels integrated into the host OS.

### Layer Tiers
- **Layer 0 (Window Host):** Base `#09090b`. Provides backdrop framing and title bar baseline.
- **Layer 1 (Recessed Well):** Darkened inset tone (`#050507`) with interior 1px stroke for terminal output displays and logs.
- **Layer 2 (Primary Shell):** Tone `#121215` with `1px solid #27272a`. The default state for sidebars and top-level layout sections.
- **Layer 3 (Inspectors & Cards):** Surface `#18181b` framed by `1px solid #27272a`. Floating cards gain an ultra-subtle top hairline highlight: `box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.05)`.
- **Layer 4 (Overlays & Menus):** Surface `#1f1f23` with a soft containment shadow: `0 12px 32px -4px rgba(0, 0, 0, 0.65), 0 0 0 1px #3f3f46`. Applied to autocomplete command palettes, model switchers, and context-menu popovers.

## Shapes
To reinforce the compact, precision-tool aesthetic of modern developer instruments, this design system operates at a **soft/compact roundedness index (Level 1)**:

- **Inputs, Buttons, and Badges:** `0.25rem` (4px). Matches the crisp geometry of code editors.
- **Panels, Model Selector Trays, and Cards:** `0.375rem` to `0.5rem` (6px to 8px). Creates clear component boundaries without wasting screen real estate.
- **Terminal Pill & Badges:** Fully circular (`9999px`) reserved strictly for live connection status chips, protocol pills, and keyboard shortcut indicators.

## Components

### 1. Tauri Window Title Bar & Gateway Pill
- **Frame:** Non-scrollable 38px flex container styled in `#09090b` with a bottom border `#27272a`.
- **Gateway Badge:** Centered or right-aligned pill with a pulsing 6px radial dot (`#10b981` online, `#f59e0b` connecting, `#ef4444` faulted), displaying text: `GATEWAY: 127.0.0.1:8787` in `code-sm` font. Right-clicking brings up the socket configuration overlay.

### 2. Sidebar Agent List
- **List Items:** 36px height rows with `0.25rem` border-radius. Inactive: `#121215` with transparent border; Active: `#18181b` with border `#27272a` and a 2px vertical emerald indicator on the far-left edge.
- **Status Indicator Dots:**
  - `Detected`: Solid `#10b981` with faint `0 0 6px rgba(16, 185, 129, 0.5)` halo.
  - `Config-Only`: Outlined ring in `#f59e0b` (no halo).
  - `Missing / Idle`: Solid `#52525b`.

### 3. Action Buttons
- **Primary (Launch / Connect):** Background `#10b981`, text `#09090b` (bold weight), border `1px solid #34d399`. Active state: `#059669`.
- **Secondary (Inspect / Probe):** Background `#18181b`, text `#f4f4f5`, border `1px solid #27272a`. Hover: border `#3f3f46`, text `#ffffff`.
- **Destructive (Kill Process):** Background `rgba(239, 68, 68, 0.1)`, text `#f87171`, border `1px solid rgba(239, 68, 68, 0.2)`. Hover: Background `#ef4444`, text `#ffffff`.

### 4. High-Density Configuration Cards
- **Structure:** Solid `#121215` panel containing grouped parameter rows. Each row is separated by a 1px border (`#1f1f23`).
- **Header Strip:** Label rendered in `label-caps` (`#a1a1aa`) accompanied by an inline action (e.g., `Reset Default` or variable schema toggle).

### 5. Model Selector Dropdown
- **Field:** Height 32px, background `#09090b`, border `1px solid #27272a`. Displays current model ID in `code-md` font (e.g., `claude-3-5-sonnet-20241022` or `llama-3.1-70b-instruct`) alongside a Cyber Cyan model parameter token (`#06b6d4`).
- **Flyout Menu:** Background `#18181b`, 1px border `#3f3f46`, with searchable filter input and sub-text indicating quantization tier and context window bounds.

### 6. Context Budget Range Slider
- **Track:** 4px tall strip with background `#27272a`, filled track dynamically colored based on capacity (`#10b981` at <70%, `#f59e0b` at 70–90%, `#ef4444` at >90%).
- **Thumb:** 14px circle in `#f4f4f5` with an inner 4px zinc core and border `1px solid #3f3f46`. Focus state exhibits an emerald ring glow.
- **Numerical readout:** Directly adjacent in `code-sm` font showing `32,768 / 131,072 tokens (25%)`.

### 7. Terminal Command Preview Pill
- **Presentation:** Recessed console block (`#050507`) with a copy button fixed to the trailing edge.
- **Prefix:** Non-selectable terminal prompt symbol `$` in Cyber Cyan (`#06b6d4`).
- **Content:** Executable string displayed in `code-sm` font with syntax highlighting: command arguments in `#f4f4f5`, flags in `#10b981`, and target directories in `#a1a1aa`.