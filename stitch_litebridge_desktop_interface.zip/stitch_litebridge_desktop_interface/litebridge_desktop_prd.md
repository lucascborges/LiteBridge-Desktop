# PRD: LiteBridge Desktop (v1.0.0-MVP)
Open-Source Desktop Orchestrator for LiteLLM & Agent Harnesses (Tauri v2 + React 19 + Tailwind CSS)

Key Sections:
- LiteLLM Gateway Connection & Health/Model Fetching (/v1/models)
- System Detection Engine ($PATH scan, Claude Desktop config discovery)
- Role-based Model Mapping Matrix (Opus, Sonnet, Haiku mappings + Context Budget slider/compact threshold)
- Dual Injection Engines: Static Config File JSON Mutator (Atomic backup/rollback) & Scoped Native Process Terminal Spawner
- Native Desktop UI: Dark-mode Zinc/Emerald accent, Window controls, Sidebar navigation, Diagnostics & Terminal logs modal.
